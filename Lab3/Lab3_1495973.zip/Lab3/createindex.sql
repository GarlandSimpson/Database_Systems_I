\i createview.sql

CREATE INDEX LookUpFlightTickets ON TICKETS(AirlineID, FlightNum);
